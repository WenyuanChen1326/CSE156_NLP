Assignment 1, Spring 2022 at UCSD

Welcome to Wenyuan Chen's CSE156 A1. Make sure HW1_2_2_combined.py, classify_2_1.py and HW1_2_1.py are in the same directory.
classify_2_1.py is to train logistic classifier
HW1_2_1,py will generate graphs and results for question 2.1 in the homework.
HW1_2_2.combined.py will generate all the graphs and results for the three models mentioned in my report. For the sake of time and memory, I commented out two of the models in the main of HW1_2_2.combined.py. If you want to explore the full results, feel free to uncomment all the functions. 

After you read all the above, then run:
 > python HW1_2_1.py
 > python HW1_2_2_combined.py
